
import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <header className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">Mytalorzone By Sahiba</a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <a className="nav-link active" aria-current="page" href="#">Home</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#collection">Collection</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#about">About Us</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#contact">Contact</a>
              </li>
            </ul>
          </div>
        </div>
      </header>

      <main>
        <section id="hero" className="text-center py-5">
          <div className="container">
            <h1>Welcome to Mytalorzone By Sahiba</h1>
            <p>Explore our exclusive clothing collection designed to inspire.</p>
            <a href="#collection" className="btn btn-primary">Shop Now</a>
          </div>
        </section>

        <section id="collection" className="py-5">
          <div className="container">
            <h2 className="text-center">Our Collection</h2>
            <div className="row">
              <div className="col-md-4">
                <div className="card">
                  <img src="images/item1.jpg" className="card-img-top" alt="Item 1" />
                  <div className="card-body">
                    <h5 className="card-title">Elegant Dress</h5>
                    <p className="card-text">Price: $50</p>
                    <a href="#" className="btn btn-secondary">View Details</a>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card">
                  <img src="images/item2.jpg" className="card-img-top" alt="Item 2" />
                  <div className="card-body">
                    <h5 className="card-title">Stylish Jacket</h5>
                    <p className="card-text">Price: $75</p>
                    <a href="#" className="btn btn-secondary">View Details</a>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card">
                  <img src="images/item3.jpg" className="card-img-top" alt="Item 3" />
                  <div className="card-body">
                    <h5 className="card-title">Trendy Shirt</h5>
                    <p className="card-text">Price: $40</p>
                    <a href="#" className="btn btn-secondary">View Details</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="py-5 bg-light">
          <div className="container">
            <h2>About Us</h2>
            <p>At Mytalorzone By Sahiba, we bring you the latest fashion trends and timeless styles. Our mission is to offer quality clothing at affordable prices.</p>
          </div>
        </section>

        <section id="contact" className="py-5">
          <div className="container">
            <h2>Contact Us</h2>
            <form>
              <div className="mb-3">
                <label htmlFor="name" className="form-label">Name</label>
                <input type="text" className="form-control" id="name" required />
              </div>
              <div className="mb-3">
                <label htmlFor="email" className="form-label">Email</label>
                <input type="email" className="form-control" id="email" required />
              </div>
              <div className="mb-3">
                <label htmlFor="message" className="form-label">Message</label>
                <textarea className="form-control" id="message" rows="3" required></textarea>
              </div>
              <button type="submit" className="btn btn-primary">Submit</button>
            </form>
          </div>
        </section>
      </main>

      <footer className="text-center py-3 bg-dark text-white">
        <p>&copy; 2024 Mytalorzone By Sahiba. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;
